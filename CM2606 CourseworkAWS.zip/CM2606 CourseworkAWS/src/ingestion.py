import boto3
import os

AWS_ACCESS_KEY = 'AKIAXX5WMIDEJTLME5NQ'        
AWS_SECRET_KEY = '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' 
BUCKET_NAME = 'cm2606-superstore-bimsaraserasinghe'       

s3 = boto3.client('s3', 
                  aws_access_key_id=AWS_ACCESS_KEY, 
                  aws_secret_access_key=AWS_SECRET_KEY)

def ingest_data():
    file_path = "data_source/Sample - Superstore.csv"
    if os.path.exists(file_path):
        s3.upload_file(file_path, BUCKET_NAME, "raw/superstore.csv")
        print("Uploaded to S3 raw folder (Data Lake)")
    else:
        print("File not found in data_source!")

if __name__ == "__main__":
    ingest_data()