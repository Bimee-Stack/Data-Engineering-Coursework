from ingestion import ingest_data
from etl import run_etl

print("Starting full AWS pipeline...")
ingest_data()
run_etl()
print("ALL DONE! Check your S3 processed folder.")