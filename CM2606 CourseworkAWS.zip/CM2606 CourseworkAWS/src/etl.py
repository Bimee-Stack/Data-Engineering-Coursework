import boto3
import pandas as pd
import os


AWS_ACCESS_KEY = 'AKIAXX5WMIDEJTLME5NQ'      
AWS_SECRET_KEY = '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'  
BUCKET_NAME = 'cm2606-superstore-bimsaraserasinghe'

s3 = boto3.client('s3', 
                  aws_access_key_id=AWS_ACCESS_KEY, 
                  aws_secret_access_key=AWS_SECRET_KEY)

def run_etl():
    print("Starting cleaning...")
    print(f"Using bucket: {BUCKET_NAME}")

    try:
        s3.download_file(BUCKET_NAME, "raw/superstore.csv", "temp.csv")
        print("File downloaded from S3 successfully")
    except Exception as e:
        print(f"Download failed: {e}")
        return

    df = pd.read_csv("temp.csv", encoding="ISO-8859-1")
    df = df.head(5000)

    df['Order Date'] = pd.to_datetime(df['Order Date'])
    df['Ship Date'] = pd.to_datetime(df['Ship Date'])
    df['Postal Code'] = df['Postal Code'].fillna(0)
    df['Discount'] = df['Discount'].fillna(0)
    df = df.drop_duplicates(subset=['Order ID', 'Row ID'])

    df['Year'] = df['Order Date'].dt.year
    df['Month'] = df['Order Date'].dt.month
    df['Profit Margin'] = (df['Profit'] / df['Sales']) * 100

    summary = df.groupby(['Year', 'Month', 'Category', 'Region', 'Segment']).agg({
        'Sales': 'sum', 'Profit': 'sum', 'Quantity': 'sum', 'Discount': 'mean'
    }).reset_index()

    summary.to_csv("clean.csv", index=False)
    s3.upload_file("clean.csv", BUCKET_NAME, "processed/clean_superstore_data.csv")
    print("Cleaning done! Data saved in S3 processed folder (Sink)")

    os.remove("temp.csv")
    os.remove("clean.csv")

if __name__ == "__main__":
    run_etl()